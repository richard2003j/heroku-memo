// The Editor standalone examples don't actually save to the database as the
// behaviour of such an edit will depend highly upon the structure of your
// database. However using the Database methods such as update() this can easily
// be done.
//
// See the Node manual - http://editor.datatables.net/manual/node - for
// information on how to use the Editor Node libraries.

let router = require('express').Router();

router.all('/api/standalone', async function(req, res) {
	res.json( { data: [req.body.data.keyless] } );
});

module.exports = router;
